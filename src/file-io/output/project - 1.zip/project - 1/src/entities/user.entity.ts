
    import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
    import { Post } from './post.entity'; 


@Entity()
export class User {

 @PrimaryGeneratedColumn("uuid")
 id: string;

    @Column({
      nullable: false,
      unique: true, 
    })
    username: string;

    @OneToMany(() => Post, (post) => post.user)
    
    posts: Post[];


}
