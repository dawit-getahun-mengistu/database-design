import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {  CreatePostDto, UpdatePostDto } from '../../dtos/post.dto';
import { Post } from '../../entities/post.entity';

@Injectable()
export class PostService {
  constructor(
    @InjectRepository(Post)
    private readonly postRepository: Repository<Post>,
  ) {}

  async findAll(): Promise<Post[]> {
    return await this.postRepository.find();
  }

  async findOne(id: string){
    return await this.postRepository.findOne({where: { id }});
  }

  async create(postDto: CreatePostDto){
    const post = this.postRepository.create(postDto);
    return await this.postRepository.save(post);
  }

  async update(id: string, postDto: UpdatePostDto){
    return await this.postRepository.update(id, postDto);
    
  }

  async remove(id: string){
    await this.postRepository.delete(id);
  }
}
