import { Module } from '@nestjs/common';
import { PostController } from "./controllers";
import { PostService } from "./services";
import { TypeOrmModule } from '@nestjs/typeorm';
import { Post } from "src/entities";

@Module({
  imports: [TypeOrmModule.forFeature([Post])],
  controllers: [PostController],
  providers: [PostService],
})
export class PostModule {}
