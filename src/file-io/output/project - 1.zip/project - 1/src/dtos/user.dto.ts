import { IsString, IsNumber, IsBoolean, IsOptional, IsArray, IsEnum } from
'class-validator'; import { PartialType } from '@nestjs/mapped-types'; export
class CreateUserDto {
    @IsString()

  username:
  string;
} export class UpdateUserDto extends PartialType(CreateUserDto) {}