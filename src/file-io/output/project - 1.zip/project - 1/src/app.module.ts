import { Module } from '@nestjs/common'; import { TypeOrmModule } from
'@nestjs/typeorm';
  import {
  UserModule } from './user/user.module';
  import {
  PostModule } from './post/post.module';
  import {
  User
  } from './entities/user.entity';
  import {
  Post
  } from './entities/post.entity';

@Module({ imports: [ TypeOrmModule.forRoot({ type: 'postgres', host:
'localhost', port: 5432, username: 'your_username', password: 'your_password',
database: 'your_database', entities: [User, Post], synchronize: true, }),
UserModule,
  PostModule
], }) export class AppModule {}