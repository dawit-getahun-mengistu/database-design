import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {  CreateUserDto, UpdateUserDto } from '../../dtos/user.dto';
import { User } from '../../entities/user.entity';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  async findAll(): Promise<User[]> {
    return await this.userRepository.find();
  }

  async findOne(id: string){
    return await this.userRepository.findOne({where: { id }});
  }

  async create(userDto: CreateUserDto){
    const user = this.userRepository.create(userDto);
    return await this.userRepository.save(user);
  }

  async update(id: string, userDto: UpdateUserDto){
    return await this.userRepository.update(id, userDto);
    
  }

  async remove(id: string){
    await this.userRepository.delete(id);
  }
}
